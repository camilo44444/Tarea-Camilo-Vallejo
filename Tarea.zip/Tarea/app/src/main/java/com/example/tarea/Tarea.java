package com.example.tarea;
package com.tuPaquete  // Cambia 'com.tuPaquete' por el nombre de tu paquete

data class Tarea(
        val nombre: String,
        val categoria: String,
        val estado: String
)
