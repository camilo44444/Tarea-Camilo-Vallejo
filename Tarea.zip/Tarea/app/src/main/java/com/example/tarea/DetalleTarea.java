package com.example.tarea;
package com.tuPaquete;  // Cambia 'com.tuPaquete' por el nombre de tu paquete

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetalleTareaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_tarea);

        String nombre = getIntent().getStringExtra("nombre");
        String categoria = getIntent().getStringExtra("categoria");
        String estado = getIntent().getStringExtra("estado");

        TextView textViewNombre = findViewById(R.id.textViewNombre);
        TextView textViewCategoria = findViewById(R.id.textViewCategoria);
        TextView textViewEstado = findViewById(R.id.textViewEstado);

        textViewNombre.setText(nombre);
        textViewCategoria.setText(categoria);
        textViewEstado.setText(estado);
    }
}
