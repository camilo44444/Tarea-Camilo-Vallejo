package com.example.tarea

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)  // Establece el layout que usará esta actividad

        // Inicialización de RecyclerView
        val recyclerView: RecyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Lista de tareas (esto es solo un ejemplo)
        val tareas = listOf(
            Tarea("Comprar alimentos", "Personal", "Pendiente"),
            Tarea("Entregar proyecto", "Trabajo", "En progreso"),
            Tarea("Llamar al médico", "Salud", "Completado")
        )

        // Inicializar el adaptador del RecyclerView
        val adapter = TareaAdapter(tareas) { tarea ->
            // Aquí se define qué pasa cuando se selecciona una tarea
            val intent = Intent(this, DetalleTareaActivity::class.java).apply {
                putExtra("nombre", tarea.nombre)
                putExtra("categoria", tarea.categoria)
                putExtra("estado", tarea.estado)
            }
            startActivity(intent)
        }

        recyclerView.adapter = adapter
    }
}
